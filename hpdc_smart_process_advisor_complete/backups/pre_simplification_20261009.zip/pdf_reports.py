"""Dependency-free, text-based PDF export for locally generated analysis reports."""
from __future__ import annotations
import re
import unicodedata


def _safe(text):
    value = unicodedata.normalize("NFKD", str(text)).encode("ascii", "ignore").decode("ascii")
    value = value.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")
    return re.sub(r"[^\x20-\x7e]", "?", value)


def _wrap(text, width=92):
    words = str(text).split()
    lines, current = [], ""
    for word in words:
        if len(current) + len(word) + (1 if current else 0) > width:
            lines.append(current)
            current = word
        else:
            current = f"{current} {word}" if current else word
    if current:
        lines.append(current)
    return lines or [""]


def build_pdf(title, lines):
    """Return a valid PDF byte stream using built-in Helvetica and US Letter pages."""
    prepared = []
    for item in [title, *lines]:
        prepared.extend(_wrap(str(item)))
    pages = [prepared[i:i + 48] for i in range(0, len(prepared), 48)] or [[]]
    objects = [b"<< /Type /Catalog /Pages 2 0 R >>", None,
               b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>"]
    page_ids = []
    for page_lines in pages:
        page_id = len(objects) + 1
        content_id = page_id + 1
        page_ids.append(page_id)
        stream_parts = ["BT", "/F1 10 Tf", "50 755 Td", "13 TL"]
        for line in page_lines:
            stream_parts.append(f"({_safe(line)}) Tj T*")
        stream_parts.append("ET")
        stream = "\n".join(stream_parts).encode("ascii")
        objects.append(f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 3 0 R >> >> /Contents {content_id} 0 R >>".encode("ascii"))
        objects.append(b"<< /Length " + str(len(stream)).encode() + b" >>\nstream\n" + stream + b"\nendstream")
    kids = " ".join(f"{value} 0 R" for value in page_ids)
    objects[1] = f"<< /Type /Pages /Kids [{kids}] /Count {len(page_ids)} >>".encode("ascii")
    output = bytearray(b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n")
    offsets = [0]
    for idx, value in enumerate(objects, 1):
        offsets.append(len(output))
        output.extend(f"{idx} 0 obj\n".encode())
        output.extend(value)
        output.extend(b"\nendobj\n")
    xref = len(output)
    output.extend(f"xref\n0 {len(offsets)}\n0000000000 65535 f \n".encode())
    for offset in offsets[1:]:
        output.extend(f"{offset:010d} 00000 n \n".encode())
    output.extend(f"trailer\n<< /Size {len(offsets)} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF".encode())
    return bytes(output)


def analysis_pdf(record):
    lines = [
        f"Component: {record['filename']}", f"Analysis time (UTC): {record['created_at']}",
        f"Analysis status: {record['status']}", "",
        "PROCESS PARAMETER ESTIMATES",
    ]
    if record.get("predictions"):
        for result in record["predictions"]:
            lines.append(f"{result['label']}: {result['value']} {result['unit']} | {result['status']} | {result.get('error', 'Validation error unavailable')} | {result.get('range_note', 'Range unknown')}")
    else:
        lines.append("Parameter estimation unavailable. No compatible, verified real-data parameter model is installed.")
    lines += ["", "MODEL PROVENANCE"]
    metadata = record.get("metadata") or {}
    lines.append(f"Model: {metadata.get('model_version') or 'not available'} ({metadata.get('model_kind') or 'no compatible model'})")
    lines.append(f"Dataset provenance: {metadata.get('dataset_provenance') or 'not available'}")
    lines.append(f"Validation method: {metadata.get('validation_method') or 'not reported'}")
    lines += ["", "ENGINEERING REVIEW"]
    for finding in record.get("findings", []):
        lines.extend([f"{finding['status']}: {finding['title']}", finding["reason"], f"Next step: {finding['next_step']}"])
    if record.get("warnings"):
        lines += ["", "WARNINGS"] + record["warnings"]
    lines += ["", "LIMITATIONS", "Part geometry alone does not determine alloy, die design, machine limits, defect risk, or optimal settings.",
              "This tool does not perform casting simulation or production approval. Qualified engineering review is required."]
    return build_pdf("HPDC Smart Process Advisor | Engineering Analysis", lines)


def comparison_pdf(title, lines):
    return build_pdf(title, lines)
