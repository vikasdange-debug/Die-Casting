# Feature implementation status

## Implemented and exercised

- FastAPI/Jinja application retained; valid/invalid upload paths return nonblank pages.
- Local STEP/STP upload with extension, size, import, unit-declaration, solid, and finite-feature checks.
- Existing 13-feature extraction schema retained for model input and internal CAD comparison; geometry metrics are hidden from the main analysis UI.
- Local browser STL viewer with rotate, zoom, pan, fit/reset, shaded/wireframe modes, keyboard rotation/zoom, and a graceful unavailable state.
- Eight-parameter dashboard and explanation/provenance slots, enabled only for a schema-compatible, provenance-attested, metric-bearing historical model.
- Engineering review guidance identifies non-assessed die/process/simulation items without declaring defects or manufacturability.
- PDF reports even when no model is installed; local history, reopen/delete, CAD feature comparison and comparison PDF, and multi-file batch/CSV summary.
- Dataset validator, blank trial CSV template, explicit grouped training workflow, and provenance metadata.
- Model/dataset health page and quality-model unavailable state.

## Deliberately limited

- **Parameter estimates:** unavailable until authorized records train a compatible model and the model metadata is reviewed. No real-data model currently exists.
- **What-if:** only compares typed alternatives arithmetically with an existing baseline. It does not rerun the geometry-only estimator, change history, or optimize.
- **CAD comparison:** compares the internal 13-feature vector and available parameter estimates. It does not identify changed faces, wall-thickness changes, or design intent.
- **PDF preview:** the report is text-based; a component preview image is not embedded.
- **Engineering checklist:** properties needing die design, process context, a suitable algorithm, simulation, or specialist review remain not assessed.

## Not available (no evidence/model/integration)

- Quality/defect classification, validated operating ranges, uncertainty intervals, parameter optimization, casting-flow/solidification simulation, production approval, and external AI assistant.
- Real foundry recommendation performance. Synthetic artifacts are archived and excluded from active inference and training.
