"""Inspect HPDC trial-table structure and provenance without modifying input."""
import argparse
from pathlib import Path
import json
import math

import pandas as pd

from train_model import (FEATURE_COLUMNS, TARGET_COLUMNS, read_table, join_geometry,
                         SYNTHETIC_MARKERS, SOURCE_TYPES, TARGET_BASES)

ID_COLUMNS = ["component_id", "trial_id", "source_type", "target_basis", "trial_accepted"]


def validate(path, frame=None):
    df = frame.copy() if frame is not None else read_table(path)
    required = ID_COLUMNS + FEATURE_COLUMNS + TARGET_COLUMNS
    missing = [name for name in required if name not in df.columns]
    markers = [c for c in ("component_id", "trial_id", "source_type") if c in df]
    synthetic_rows = int(df[markers].astype(str).apply(lambda col: col.str.contains(SYNTHETIC_MARKERS, case=False, regex=True)).any(axis=1).sum()) if markers else 0
    numeric = FEATURE_COLUMNS + TARGET_COLUMNS + ["trial_accepted"]
    bad_numeric = {}
    for col in [c for c in numeric if c in df]:
        parsed = pd.to_numeric(df[col], errors="coerce")
        count = int((parsed.isna() | ~parsed.map(math.isfinite)).sum())
        if count:
            bad_numeric[col] = count
    positive_fields = [c for c in ["length_mm", "width_mm", "height_mm", "volume_mm3", "surface_area_mm2",
                                    "length_width_ratio", "length_height_ratio", "width_height_ratio",
                                    "surface_area_volume_ratio"] + TARGET_COLUMNS if c in df]
    invalid_measurements = {col: int((pd.to_numeric(df[col], errors="coerce") <= 0).sum())
                            for col in positive_fields if (pd.to_numeric(df[col], errors="coerce") <= 0).any()}
    topology_fields = [c for c in ("solid_count", "face_count", "edge_count", "vertex_count") if c in df]
    for col in topology_fields:
        values = pd.to_numeric(df[col], errors="coerce")
        if ((values < 0) | (values % 1 != 0)).any():
            invalid_measurements[col] = int(((values < 0) | (values % 1 != 0)).sum())
    duplicates = int(df["trial_id"].duplicated().sum()) if "trial_id" in df else None
    source_types = sorted(df["source_type"].dropna().astype(str).unique().tolist()) if "source_type" in df else []
    target_bases = sorted(df["target_basis"].dropna().astype(str).unique().tolist()) if "target_basis" in df else []
    accepted_count = int((pd.to_numeric(df["trial_accepted"], errors="coerce") == 1).sum()) if "trial_accepted" in df else 0
    missing_values = {col: int(df[col].isna().sum()) for col in required if col in df and df[col].isna().any()}
    component_count = int(df.component_id.nunique()) if "component_id" in df else None
    eligible = (not missing and synthetic_rows == 0 and duplicates == 0 and not bad_numeric and not invalid_measurements and not missing_values
                and bool(source_types) and set(source_types) <= SOURCE_TYPES
                and len(target_bases) == 1 and set(target_bases) <= TARGET_BASES
                and accepted_count >= 20 and (component_count or 0) >= 5)
    return {"file": str(path), "rows": int(len(df)), "columns": list(df.columns), "missing_required_columns": missing,
            "missing_values": missing_values, "component_count": component_count, "accepted_rows": accepted_count,
            "duplicate_trial_ids": duplicates, "source_types": source_types, "target_bases": target_bases,
            "synthetic_marker_rows": int(synthetic_rows), "invalid_or_missing_numeric_values": bad_numeric,
            "invalid_measurements": invalid_measurements,
            "real_data_training_eligible": eligible}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", required=True, help="CSV or Excel trial table")
    parser.add_argument("--report", help="Optional JSON validation report output")
    parser.add_argument("--geometry", help="Optional CAD feature file to check/join by component_id")
    args = parser.parse_args()
    try:
        trial_data = read_table(args.data)
        geometry_join = "Not requested; geometry must already be present in the trial table."
        if args.geometry:
            trial_data = join_geometry(trial_data, read_table(args.geometry))
            geometry_join = f"Joined {args.geometry} on component_id (many trials to one CAD row)."
        result = validate(args.data) if not args.geometry else validate_frame(trial_data, args.data, geometry_join)
    except Exception as exc:
        raise SystemExit(f"Could not read dataset: {exc}") from exc
    rendered = json.dumps(result, indent=2)
    print(rendered)
    if args.report:
        Path(args.report).write_text(rendered + "\n", encoding="utf-8")
    if not result["real_data_training_eligible"]:
        raise SystemExit("Dataset is not eligible for real-data training. Review missing fields and provenance; synthetic data is never relabelled as real.")


def validate_frame(df, path, geometry_join):
    """Validate joined rows without writing an intermediate trial file."""
    base = validate(path, frame=df)
    base["geometry_join"] = geometry_join
    return base


if __name__ == "__main__":
    main()
