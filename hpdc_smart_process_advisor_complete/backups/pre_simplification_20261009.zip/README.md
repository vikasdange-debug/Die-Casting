# HPDC Smart Process Advisor

Local FastAPI application for processing STEP/STP CAD components, reviewing cautious HPDC engineering guidance, and estimating historical process settings only when a compatible, provenance-verified model is installed. CAD processing and reports work without a model. The current repository has **no verified real-data model**, so the eight parameter estimates are unavailable by default.

The interface focuses on process outputs and findings. CAD-derived measurements stay internal for inference and comparison; they are not presented as a geometry dashboard. CAD files stay in local project storage and are not sent to an external viewer or service.

## Windows PowerShell setup

Run from the repository folder:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
python -m pytest -q
uvicorn app:app --reload
```

Open `http://127.0.0.1:8000`. If PowerShell blocks environment activation, allow it for this terminal only with `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass`, then activate again.

## Use the application

1. Select a `.step` or `.stp` component (up to 25 MB) and choose **Analyze component**.
2. The app imports the CAD locally, checks geometry, extracts model features, and saves analysis metadata in the local SQLite history. A private STL preview is generated for the browser viewer.
3. Review estimates if a compatible verified model is installed. Otherwise, the result page clearly states that estimates are unavailable; no placeholder predictions are generated.
4. Review engineering checks. Items needing die design, process data, simulation, or engineer review remain “Not assessed.”
5. Download a PDF, compare two CAD files, explore batch processing, or revisit/delete analyses from History.

The what-if page compares typed alternatives with a baseline estimate. It does not rerun the current geometry-only model and is explicitly exploratory. CAD comparison only reports whether the supported feature vector changed; it does not identify every changed face or design intent. No quality prediction is provided without an appropriate labelled quality model. No external AI assistant or optimizer is configured.

## Data and training

There are no verified production, experimental, or validated simulation trials in this repository. The former `real_hpdc_trials.csv` was found to contain generated `DEMO_*` identifiers and has been renamed to `data/archived_mislabeled_synthetic_trials.csv`. The original demo CSV and synthetic model are retained as clearly named archival artifacts; none are loaded by the app or selected by the trainer. The active model slot is `models/hpdc_process_model.joblib` with `models/hpdc_process_model_metadata.json`.

Start from the header-only [`data/template_hpdc_trials.csv`](data/template_hpdc_trials.csv). Add only authorized records with source evidence, stable component/trial IDs, all 13 CAD features or a separate CAD feature export, all eight targets, explicit units, target basis, source type, and acceptance label. Keep measured production, experimental, and validated simulation records appropriately classified. Do not claim structural validation proves provenance.

```powershell
python validate_dataset.py --data data\your_authorized_trials.csv --report data\validation_report.json
python train_model.py --data data\your_authorized_trials.csv --confirm-authorized-data
```

If geometry is in a separate file, add `--geometry data\geometry_features.csv` to both commands. Training intentionally requires `--confirm-authorized-data`; use it only after verifying authorization and the declared provenance. Validation rejects synthetic markers, missing fields, duplicate trial IDs, invalid values, mixed target bases, and inadequate grouped splits. Training uses a reproducible group holdout by `component_id`, reports per-target MAE/RMSE and a mean baseline, and writes model and metadata only after successful evaluation. This is historical-setting estimation, not optimization or quality prediction. The active app additionally requires a true `provenance_verified` field and exact feature/target schemas.

Vacuum is absolute mbar. The model schema is the existing 13-feature CAD schema and eight target schema; do not change feature order without an intentional retrain and verification. Training target ranges are observed dataset coverage, not machine operating limits. There are no verified operating limits configured.

## Storage and privacy

Analysis metadata is stored in `data/analysis_history.sqlite3`. Original uploads and local preview meshes are stored under `uploads/` using random identifiers; they are not publicly listed. Delete records and their files from the History page. Keep the workspace on storage suitable for proprietary CAD and apply your organization's normal access controls. This local demo has not undergone a production security assessment.

## Current feature limits

- CAD geometry import, 13-feature extraction, local viewer, historical comparison, batch processing, PDF reports, and analysis history work independently of ML.
- No compatible real-data parameter model or quality classifier is present.
- Wall thickness, draft, undercuts, gate/runner, vent/vacuum, cooling, and casting fill/solidification are not inferred from the part CAD alone. No casting simulation is performed.
- Model feature importance is shown only when the loaded estimator supports it. It describes model association, not causality.
- AI assistant, validated optimization, safe machine limits, and production approval are not provided.

See [`PROJECT_AUDIT.md`](PROJECT_AUDIT.md), [`FEATURE_STATUS.md`](FEATURE_STATUS.md), and [`TEST_REPORT.md`](TEST_REPORT.md) for audit findings, feature status, and executed test results.
