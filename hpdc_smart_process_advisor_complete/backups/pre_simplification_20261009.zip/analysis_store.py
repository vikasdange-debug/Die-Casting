"""Small local SQLite history store; CAD files remain in the private uploads folder."""
from __future__ import annotations
import json
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DATABASE_PATH = ROOT / "data" / "analysis_history.sqlite3"
UPLOADS_PATH = ROOT / "uploads"


@contextmanager
def connect():
    db = sqlite3.connect(DATABASE_PATH, timeout=15)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA foreign_keys=ON")
    try:
        yield db
    except Exception:
        db.rollback()
        raise
    else:
        db.commit()
    finally:
        db.close()


def initialize():
    with connect() as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS analyses (
          analysis_id TEXT PRIMARY KEY, created_at TEXT NOT NULL, filename TEXT NOT NULL,
          cad_path TEXT NOT NULL, mesh_path TEXT, features_json TEXT NOT NULL,
          predictions_json TEXT NOT NULL, metadata_json TEXT, warnings_json TEXT NOT NULL,
          findings_json TEXT NOT NULL, status TEXT NOT NULL, explanation_json TEXT
        );
        CREATE TABLE IF NOT EXISTS what_if_scenarios (
          scenario_id TEXT PRIMARY KEY, analysis_id TEXT NOT NULL REFERENCES analyses(analysis_id) ON DELETE CASCADE,
          created_at TEXT NOT NULL, values_json TEXT NOT NULL, differences_json TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS comparisons (
          comparison_id TEXT PRIMARY KEY, created_at TEXT NOT NULL,
          first_analysis_id TEXT NOT NULL REFERENCES analyses(analysis_id),
          second_analysis_id TEXT NOT NULL REFERENCES analyses(analysis_id), details_json TEXT NOT NULL
        );
        """)
        columns = {row["name"] for row in db.execute("PRAGMA table_info(analyses)")}
        if "explanation_json" not in columns:
            db.execute("ALTER TABLE analyses ADD COLUMN explanation_json TEXT")


def now_utc():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def save_analysis(record):
    with connect() as db:
        db.execute("""INSERT INTO analyses
                   (analysis_id,created_at,filename,cad_path,mesh_path,features_json,predictions_json,metadata_json,warnings_json,findings_json,status,explanation_json)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                   (record["analysis_id"], record["created_at"], record["filename"], record["cad_path"],
                    record.get("mesh_path"), json.dumps(record["features"]), json.dumps(record.get("predictions", [])),
                    json.dumps(record["metadata"]) if record.get("metadata") else None,
                    json.dumps(record.get("warnings", [])), json.dumps(record.get("findings", [])), record["status"],
                    json.dumps(record.get("explanation", {}))))


def _decode(row):
    if row is None:
        return None
    item = dict(row)
    for field, target in [("features_json", "features"), ("predictions_json", "predictions"),
                          ("metadata_json", "metadata"), ("warnings_json", "warnings"),
                          ("findings_json", "findings"), ("explanation_json", "explanation")]:
        raw = item.pop(field)
        item[target] = json.loads(raw) if raw else None
    return item


def get_analysis(analysis_id):
    with connect() as db:
        return _decode(db.execute("SELECT * FROM analyses WHERE analysis_id=?", (analysis_id,)).fetchone())


def list_analyses(limit=100):
    with connect() as db:
        rows = db.execute("SELECT * FROM analyses ORDER BY created_at DESC LIMIT ?", (limit,)).fetchall()
    return [_decode(row) for row in rows]


def save_scenario(scenario_id, analysis_id, values, differences):
    with connect() as db:
        db.execute("INSERT INTO what_if_scenarios VALUES (?, ?, ?, ?, ?)",
                   (scenario_id, analysis_id, now_utc(), json.dumps(values), json.dumps(differences)))


def latest_scenario(analysis_id):
    with connect() as db:
        row = db.execute("SELECT * FROM what_if_scenarios WHERE analysis_id=? ORDER BY created_at DESC LIMIT 1", (analysis_id,)).fetchone()
    if not row:
        return None
    return {"scenario_id": row["scenario_id"], "created_at": row["created_at"],
            "values": json.loads(row["values_json"]), "differences": json.loads(row["differences_json"])}


def save_comparison(comparison_id, first_id, second_id, details):
    with connect() as db:
        db.execute("INSERT INTO comparisons VALUES (?, ?, ?, ?, ?)",
                   (comparison_id, now_utc(), first_id, second_id, json.dumps(details)))


def get_comparison(comparison_id):
    with connect() as db:
        row = db.execute("SELECT * FROM comparisons WHERE comparison_id=?", (comparison_id,)).fetchone()
    if not row:
        return None
    return {"comparison_id": row["comparison_id"], "created_at": row["created_at"],
            "first_analysis_id": row["first_analysis_id"], "second_analysis_id": row["second_analysis_id"],
            "details": json.loads(row["details_json"])}


def delete_analysis(analysis_id):
    record = get_analysis(analysis_id)
    if record is None:
        return False
    # Storage paths are generated by the app under uploads; reject unexpected paths.
    uploads_root = UPLOADS_PATH.resolve()
    paths = [record.get("cad_path"), record.get("mesh_path")]
    with connect() as db:
        db.execute("DELETE FROM comparisons WHERE first_analysis_id=? OR second_analysis_id=?", (analysis_id, analysis_id))
        db.execute("DELETE FROM analyses WHERE analysis_id=?", (analysis_id,))
    for value in paths:
        if value:
            path = Path(value).resolve()
            if path.is_relative_to(uploads_root) and path.is_file():
                path.unlink()
    return True


initialize()
