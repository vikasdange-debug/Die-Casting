import json
from pathlib import Path
import uuid

from fastapi.testclient import TestClient
import pandas as pd
import pytest

import analysis_store as store
import app as webapp
from cad_feature_extractor import FEATURE_NAMES, extract_step_features
from pdf_reports import analysis_pdf
from train_model import TARGET_COLUMNS

ROOT = Path(__file__).resolve().parents[1]
FIXTURE = ROOT / "uploads" / "cf1e58ef37034085952301024873e32d.step"
client = TestClient(webapp.app)


def isolated_history(monkeypatch):
    path = ROOT / "data" / f"test_history_{uuid.uuid4().hex}.sqlite3"
    monkeypatch.setattr(store, "DATABASE_PATH", path)
    store.initialize()
    return path


def test_home_and_navigation_render_upload_and_model_status():
    response = client.get("/")
    assert response.status_code == 200
    assert 'name="file"' in response.text
    assert "Upload component" in response.text
    assert "No verified real-data model" in response.text
    assert client.get("/model-health").status_code == 200
    assert client.get("/history").status_code == 200


def test_known_step_fixture_extraction_schema_and_multiple_solids():
    features, warnings = extract_step_features(FIXTURE, include_warnings=True)
    assert list(features) == FEATURE_NAMES
    assert features["solid_count"] == 2
    assert all(value >= 0 for value in features.values())
    assert isinstance(warnings, list)


def test_valid_upload_returns_nonblank_estimate_unavailable_page_and_private_preview():
    response = client.post("/analyze", files={"file": ("housing.step", FIXTURE.read_bytes(), "application/step")})
    assert response.status_code == 200 and len(response.text) > 1000
    assert "Parameter estimates unavailable" in response.text
    assert "No process values have been generated" in response.text
    assert "Geometry overview" not in response.text and "volume_mm3" not in response.text
    assert "SYNTHETIC DEMONSTRATION ONLY" not in response.text
    analysis_id = response.text.split('/analysis/', 1)[1].split('/', 1)[0]
    assert client.get(f"/analysis/{analysis_id}/mesh").status_code == 200
    report = client.get(f"/analysis/{analysis_id}/report.pdf")
    assert report.status_code == 200 and report.content.startswith(b"%PDF-")
    assert b"Parameter estimation unavailable" in report.content


def test_invalid_extension_empty_and_malformed_uploads_are_actionable():
    ext = client.post("/analyze", files={"file": ("part.txt", b"hello", "text/plain")})
    empty = client.post("/analyze", files={"file": ("empty.step", b"", "application/step")})
    broken = client.post("/analyze", files={"file": ("broken.stp", b"not a STEP file", "application/step")})
    assert ext.status_code == 415 and "Only .step and .stp" in ext.text and "<html" in ext.text.lower()
    assert empty.status_code == 400 and "empty" in empty.text.lower()
    assert broken.status_code == 422 and len(broken.text) > 300


def test_upload_limit_returns_html_error(monkeypatch):
    monkeypatch.setattr(webapp, "MAX_UPLOAD_BYTES", 4)
    response = client.post("/analyze", files={"file": ("large.step", b"12345", "application/step")})
    assert response.status_code == 413 and "25 MB" in response.text


def test_active_model_slot_is_empty_and_archived_synthetic_model_is_rejected(monkeypatch):
    model, metadata, issue = webapp.load_model()
    assert model is None and metadata is None and "No verified real-data model" in issue
    archived_model = ROOT / "models" / "archived_synthetic_model.joblib"
    archived_metadata = ROOT / "models" / "archived_synthetic_model_metadata.json"
    if archived_model.exists() and archived_metadata.exists():
        monkeypatch.setattr(webapp, "MODEL_PATH", archived_model)
        monkeypatch.setattr(webapp, "META_PATH", archived_metadata)
        model, metadata, issue = webapp.load_model()
        assert model is None and metadata is None and "unavailable" in issue.lower()


def test_schema_mismatch_rejected_before_model_load(monkeypatch):
    meta = {"model_kind": "historical_setting_estimator", "provenance_verified": True,
            "feature_columns": ["wrong"], "target_columns": TARGET_COLUMNS,
            "metrics": {}, "dataset_provenance": "verified_experimental", "training_date_utc": "today"}
    monkeypatch.setattr(webapp, "MODEL_PATH", ROOT / "models" / "archived_synthetic_model.joblib")
    monkeypatch.setattr(webapp, "META_PATH", ROOT / "models" / "archived_synthetic_model_metadata.json")
    monkeypatch.setattr(webapp.json, "loads", lambda value: meta)
    model, metadata, issue = webapp.load_model()
    assert model is None and "feature schema" in issue.lower()


def test_prediction_adapter_formats_all_eight_targets(monkeypatch):
    class Model:
        def predict(self, frame):
            assert list(frame.columns) == FEATURE_NAMES
            return [[1.0, 2.0, 0.2, 50.0, 1.5, 100.0, 3.0, 30.0]]
    metadata = {"feature_columns": FEATURE_NAMES, "target_columns": TARGET_COLUMNS,
                "metrics": {key: {"mae": 0.1, "rmse": 0.2} for key in TARGET_COLUMNS},
                "target_ranges": {}, "feature_ranges": {key: {"min": 0, "max": 1e9} for key in FEATURE_NAMES}}
    monkeypatch.setattr(webapp, "load_model", lambda: (Model(), metadata, None))
    features, _ = extract_step_features(FIXTURE, include_warnings=True)
    rows, used_metadata, issue, explanation, warnings = webapp.predict_parameters(features)
    assert issue is None and used_metadata is metadata
    assert [row["name"] for row in rows] == TARGET_COLUMNS
    assert all(row["unit"] and row["error"] for row in rows)
    assert explanation["available"] is False and not warnings


def test_what_if_unavailable_without_verified_baseline():
    response = client.post("/analyze", files={"file": ("part.step", FIXTURE.read_bytes(), "application/step")})
    analysis_id = response.text.split('/analysis/', 1)[1].split('/', 1)[0]
    what_if = client.post(f"/analysis/{analysis_id}/what-if", data={"melt_temperature_C": "700"})
    assert "What-if comparison needs baseline parameter estimates" in what_if.text
    assert "No optimized settings are proposed" in response.text


def test_what_if_comparison_keeps_baseline_unchanged(monkeypatch):
    model_info = {"model_version": "test-adapter", "dataset_provenance": "verified_experimental",
                  "training_date_utc": "2026-10-09", "validation_method": "grouped holdout"}
    prediction_rows = [{"name": key, "label": webapp.TARGETS[key][0], "value": "10", "numeric_value": 10.0,
                        "unit": webapp.TARGETS[key][1], "description": "test", "status": "Range unknown",
                        "training_range": "Not reported", "error": "MAE 1; RMSE 2"} for key in TARGET_COLUMNS]
    monkeypatch.setattr(webapp, "predict_parameters", lambda features: (prediction_rows, model_info, None,
                                                                          {"available": False, "text": "No explanation"}, []))
    response = client.post("/analyze", files={"file": ("what-if.step", FIXTURE.read_bytes(), "application/step")})
    analysis_id = response.text.split('/analysis/', 1)[1].split('/', 1)[0]
    alternative = client.post(f"/analysis/{analysis_id}/what-if", data={"melt_temperature_C": "12"})
    assert alternative.status_code == 200 and "+2" in alternative.text
    assert "Baseline analysis is unchanged" in alternative.text
    assert store.get_analysis(analysis_id)["predictions"][0]["numeric_value"] == 10


def test_comparison_and_batch_work_without_model():
    two = FIXTURE.read_bytes()
    compared = client.post("/compare", files={"first_file": ("a.step", two, "application/step"),
                                             "second_file": ("b.step", two, "application/step")})
    assert compared.status_code == 200 and "Parameter comparison unavailable" in compared.text
    batch = client.post("/batch", files=[("files", ("a.step", two, "application/step"))])
    assert batch.status_code == 200 and "Download CSV" in batch.text


def test_pdf_builder_has_no_raw_geometry_metrics():
    assert analysis_pdf({"filename": "part.step", "created_at": "2026-01-01T00:00:00+00:00",
                         "predictions": [], "metadata": None, "warnings": [], "findings": [],
                         "status": "unavailable"}).startswith(b"%PDF-")
    assert b"volume_mm3" not in analysis_pdf({"filename": "part.step", "created_at": "now", "predictions": [],
                                                "metadata": None, "warnings": [], "findings": [], "status": "unavailable"})


def test_history_reopen_and_delete(monkeypatch):
    path = isolated_history(monkeypatch)
    cad_path = ROOT / "uploads" / "does-not-exist.step"
    record = {"analysis_id": "test-" + uuid.uuid4().hex, "created_at": store.now_utc(), "filename": "old.step",
              "cad_path": str(cad_path), "mesh_path": None, "features": {k: 1 for k in FEATURE_NAMES},
              "predictions": [], "metadata": None, "warnings": [], "findings": [], "status": "unavailable",
              "explanation": {"available": False, "text": "No model"}}
    store.save_analysis(record)
    assert store.get_analysis(record["analysis_id"])["explanation"]["available"] is False
    assert client.get(f"/analysis/{record['analysis_id']}").status_code == 200
    assert store.delete_analysis(record["analysis_id"])
    assert store.get_analysis(record["analysis_id"]) is None
    path.unlink(missing_ok=True)


def test_dataset_validation_refuses_synthetic_markers():
    from validate_dataset import validate
    report = validate("archived input", frame=pd.DataFrame({"component_id": ["DEMO_PART_1"], "trial_id": ["DEMO_TRIAL_1"]}))
    assert report["synthetic_marker_rows"] == 1
    assert not report["real_data_training_eligible"]
