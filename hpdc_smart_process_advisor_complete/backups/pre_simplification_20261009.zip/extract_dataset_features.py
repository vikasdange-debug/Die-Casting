"""Extract geometry features from all STEP/STP files in a folder to CSV."""
import argparse
from pathlib import Path
import pandas as pd
from cad_feature_extractor import extract_step_features

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input-folder", required=True, help="Folder containing STEP/STP files")
    parser.add_argument("--output", default="data/geometry_features.csv", help="Output CSV path")
    args = parser.parse_args()

    folder = Path(args.input_folder)
    if not folder.is_dir():
        raise SystemExit(f"Input folder does not exist: {folder}")

    rows = []
    seen_ids = set()
    for path in sorted(folder.rglob("*")):
        if path.is_file() and path.suffix.lower() in {".step", ".stp"}:
            try:
                component_id = path.stem
                if component_id in seen_ids:
                    print(f"SKIP: {path.name}: duplicate component_id from filename stem {component_id!r}; use unique source names/IDs")
                    continue
                row = {"component_id": component_id, "source_file": str(path)}
                features, warnings = extract_step_features(path, include_warnings=True)
                row.update(features)
                row["geometry_unit_interpretation"] = "STEP length unit declared; Open CASCADE converted import to mm; verify intended part scale"
                row["extraction_warnings"] = " | ".join(warnings)
                rows.append(row)
                seen_ids.add(component_id)
                print(f"OK: {path.name}")
            except Exception as exc:
                print(f"SKIP: {path.name}: {exc}")

    if not rows:
        raise SystemExit("No STEP files were processed successfully.")

    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(output, index=False)
    print(f"\nSaved {len(rows)} component rows to {output}")

if __name__ == "__main__":
    main()
