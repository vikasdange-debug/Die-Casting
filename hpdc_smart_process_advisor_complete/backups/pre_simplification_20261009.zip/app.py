"""Local, CAD-driven HPDC process advisor."""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
import json
import logging
import math
import uuid

import joblib
import pandas as pd
from fastapi import FastAPI, File, Form, Request, UploadFile
from fastapi.exceptions import RequestValidationError
from fastapi.responses import FileResponse, HTMLResponse, Response
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.base import BaseHTTPMiddleware

import analysis_store as store
from cad_feature_extractor import FEATURE_NAMES, extract_step_features
from engineering_rules import get_engineering_findings
from pdf_reports import analysis_pdf, comparison_pdf

ROOT = Path(__file__).resolve().parent
UPLOAD_DIR = store.UPLOADS_PATH
MODEL_PATH = ROOT / "models" / "hpdc_process_model.joblib"
META_PATH = ROOT / "models" / "hpdc_process_model_metadata.json"
MAX_UPLOAD_BYTES = 25 * 1024 * 1024
MAX_BATCH_FILES = 10
MAX_BATCH_BYTES = 100 * 1024 * 1024
logger = logging.getLogger("hpdc_advisor")
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")

TARGETS = {
    "melt_temperature_C": ("Melt temperature", "°C", "Temperature of the molten metal entering the shot system."),
    "die_temperature_C": ("Die temperature", "°C", "Die thermal condition at the specified measurement or setpoint location."),
    "filling_time_s": ("Filling time", "s", "Time for the cavity to fill under the recorded trial definition."),
    "intensification_pressure_MPa": ("Intensification pressure", "MPa", "Pressure applied during the intensification phase."),
    "fast_shot_speed_m_s": ("Fast-shot speed", "m/s", "Plunger speed during the fast-shot phase."),
    "vacuum_pressure_mbar_abs": ("Vacuum pressure", "mbar abs", "Absolute pressure; confirm the sensor point and measurement basis."),
    "cooling_time_s": ("Cooling time", "s", "Recorded cooling/solidification time for the trial."),
    "gate_velocity_m_s": ("Gate velocity", "m/s", "Gate metal velocity; strongly dependent on die and gate design."),
}
TARGET_ORDER = list(TARGETS)

app = FastAPI(title="HPDC Smart Process Advisor", version="3.0")
app.mount("/static", StaticFiles(directory=ROOT / "static"), name="static")
templates = Jinja2Templates(directory=ROOT / "templates")


class RequestSizeLimitMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        limits = {"/analyze": MAX_UPLOAD_BYTES + 1024 * 1024,
                  "/compare": 2 * MAX_UPLOAD_BYTES + 2 * 1024 * 1024,
                  "/batch": MAX_BATCH_BYTES + 2 * 1024 * 1024}
        limit = limits.get(request.url.path)
        if limit is not None:
            try:
                if int(request.headers.get("content-length", "0")) > limit:
                    return render(request, "index.html", error="The upload is larger than the allowed request size. Choose smaller STEP/STP files.", status_code=413)
            except ValueError:
                pass
        return await call_next(request)


app.add_middleware(RequestSizeLimitMiddleware)


def load_model():
    """Load only a complete, explicitly provenance-attested real-data model."""
    if not MODEL_PATH.is_file() or not META_PATH.is_file():
        return None, None, "Parameter estimation is unavailable. No verified real-data model is configured; CAD processing and engineering review remain available."
    try:
        metadata = json.loads(META_PATH.read_text(encoding="utf-8"))
        if metadata.get("model_kind") != "historical_setting_estimator":
            raise ValueError("The model is not a supported historical-setting estimator.")
        if metadata.get("provenance_verified") is not True:
            raise ValueError("Model data provenance has not been explicitly verified.")
        provenance = str(metadata.get("dataset_provenance", "")).lower()
        if any(marker in provenance for marker in ("synthetic", "demo", "generated", "artificial", "unknown")):
            raise ValueError("Model provenance identifies synthetic, generated, or unverified data.")
        if metadata.get("feature_columns") != FEATURE_NAMES:
            raise ValueError("Model feature schema does not exactly match the current CAD feature schema.")
        if metadata.get("target_columns") != TARGET_ORDER:
            raise ValueError("Model target schema does not match the eight configured parameters.")
        metrics = metadata.get("metrics")
        if not isinstance(metrics, dict) or any(not isinstance(metrics.get(key), dict) or not {"mae", "rmse"} <= set(metrics[key]) for key in TARGET_ORDER):
            raise ValueError("Per-target validation metrics are missing.")
        if any(not math.isfinite(float(metrics[key][metric])) or float(metrics[key][metric]) < 0
               for key in TARGET_ORDER for metric in ("mae", "rmse")):
            raise ValueError("Per-target validation metrics are invalid.")
        if not metadata.get("dataset_provenance") or not metadata.get("training_date_utc"):
            raise ValueError("Dataset provenance or training date is missing.")
        model = joblib.load(MODEL_PATH)
        if getattr(model, "n_features_in_", len(FEATURE_NAMES)) != len(FEATURE_NAMES):
            raise ValueError("The saved estimator expects a different number of features.")
        regressor = getattr(model, "named_steps", {}).get("regressor")
        if regressor is not None:
            if hasattr(regressor, "n_jobs"):
                regressor.n_jobs = 1
            for estimator in getattr(regressor, "estimators_", []):
                if hasattr(estimator, "set_params") and "n_jobs" in estimator.get_params():
                    estimator.set_params(n_jobs=1)
        return model, metadata, None
    except Exception as exc:
        logger.exception("Active model failed provenance or schema checks")
        return None, None, f"Parameter estimation is unavailable because the configured model did not pass validation ({exc})."


def render(request, name, *, status_code=200, **context):
    return templates.TemplateResponse(request=request, name=name, status_code=status_code, context=context)


def analysis_view(record, scenario=None):
    return {"analysis": record, "predictions": record["predictions"], "findings": record["findings"],
            "warnings": record["warnings"], "metadata": record["metadata"], "scenario": scenario,
            "estimate_status": record["status"], "model_available": bool(record["predictions"])}


def explain_model(model, metadata):
    if model is None:
        return {"available": False, "text": "No verified model is installed, so no feature-importance explanation is available."}
    importance = []
    try:
        regressor = model.named_steps["regressor"]
        importances = [est.feature_importances_ for est in regressor.estimators_ if hasattr(est, "feature_importances_")]
        if importances:
            mean_values = pd.Series(sum(importances) / len(importances), index=metadata["feature_columns"])
            friendly = {"length_mm": "overall part scale", "width_mm": "overall part scale", "height_mm": "overall part scale",
                        "volume_mm3": "part volume", "surface_area_mm2": "surface complexity", "solid_count": "solid count",
                        "face_count": "surface topology", "edge_count": "surface topology", "vertex_count": "surface topology",
                        "length_width_ratio": "bounding proportions", "length_height_ratio": "bounding proportions",
                        "width_height_ratio": "bounding proportions", "surface_area_volume_ratio": "surface complexity"}
            importance = [{"label": friendly.get(key, key), "value": float(mean_values[key])} for key in mean_values.nlargest(3).index]
    except Exception:
        logger.exception("Could not derive model feature importance")
    text = "The model learned associations between CAD-derived part size, proportions, and topology and historical recorded settings. These are associations, not causal effects; alloy, die, gating, machine, and process context may materially change the settings."
    return {"available": bool(importance), "text": text if importance else "This estimator does not expose a supported feature-importance method; no explanation has been inferred.",
            "features": importance}


def predict_parameters(features):
    model, metadata, issue = load_model()
    if model is None:
        return [], None, issue, explain_model(None, None), []
    try:
        row = pd.DataFrame([{key: features[key] for key in metadata["feature_columns"]}])
        output = model.predict(row)[0]
        if len(output) != len(TARGET_ORDER):
            raise ValueError("Model did not return all eight configured targets.")
        values = []
        for key, raw in zip(TARGET_ORDER, output):
            value = float(raw)
            if not math.isfinite(value):
                raise ValueError(f"Estimator returned a non-finite value for {key}.")
            label, unit, description = TARGETS[key]
            metric = metadata["metrics"][key]
            target_range = (metadata.get("target_ranges") or {}).get(key)
            range_text = f"{target_range['min']:g}–{target_range['max']:g} {unit}" if target_range else "Not reported"
            target_status = "Within recorded target range" if target_range and target_range["min"] <= value <= target_range["max"] else "Outside recorded range" if target_range else "Range unknown"
            values.append({"name": key, "label": label, "value": f"{value:.4g}", "numeric_value": value, "unit": unit,
                           "description": description, "status": target_status, "training_range": range_text,
                           "error": f"MAE {float(metric['mae']):.4g}; RMSE {float(metric['rmse']):.4g} {unit}"})
        coverage_warnings = []
        feature_ranges = metadata.get("feature_ranges") or {}
        for key in metadata["feature_columns"]:
            bounds = feature_ranges.get(key)
            if bounds and not bounds.get("min", -math.inf) <= features[key] <= bounds.get("max", math.inf):
                coverage_warnings.append("Component falls outside the model's recorded training-feature range. Estimates may be extrapolations.")
                break
        if not feature_ranges:
            coverage_warnings.append("Training-feature coverage was not recorded; out-of-distribution status is unknown.")
        if any(v["status"] == "Outside recorded range" for v in values):
            coverage_warnings.append("At least one estimate is outside its recorded training-target range; this is not a machine limit.")
        return values, metadata, None, explain_model(model, metadata), coverage_warnings
    except Exception as exc:
        logger.exception("Parameter prediction failed")
        return [], metadata, f"CAD processing succeeded, but parameter estimation failed ({exc}).", explain_model(None, None), []


async def read_upload(upload: UploadFile):
    filename = Path(upload.filename or "").name
    suffix = Path(filename).suffix.lower()
    try:
        if suffix not in {".step", ".stp"}:
            raise ValueError("Only .step and .stp CAD files are supported.")
        content = await upload.read(MAX_UPLOAD_BYTES + 1)
    finally:
        await upload.close()
    if not content:
        raise ValueError("The selected CAD file is empty.")
    if len(content) > MAX_UPLOAD_BYTES:
        raise OverflowError("Each CAD file must be 25 MB or smaller.")
    return filename, suffix, content


def process_content(filename, suffix, content):
    analysis_id = uuid.uuid4().hex
    cad_path = UPLOAD_DIR / f"{analysis_id}{suffix}"
    mesh_path = UPLOAD_DIR / f"{analysis_id}.stl"
    try:
        cad_path.write_bytes(content)
        features, warnings = extract_step_features(cad_path, include_warnings=True, mesh_path=mesh_path)
        if not mesh_path.is_file():
            mesh_path = None
    except Exception:
        cad_path.unlink(missing_ok=True)
        mesh_path.unlink(missing_ok=True)
        raise
    predictions, metadata, issue, explanation, coverage = predict_parameters(features)
    warnings.extend(coverage)
    if issue:
        warnings.append(issue)
    findings = get_engineering_findings(features)
    status = "Historical-setting estimates available" if predictions else "CAD analysis completed; parameter estimation unavailable"
    record = {"analysis_id": analysis_id, "created_at": store.now_utc(), "filename": filename,
              "cad_path": str(cad_path), "mesh_path": str(mesh_path) if mesh_path else None,
              "features": features, "predictions": predictions, "metadata": metadata, "warnings": warnings,
              "findings": findings, "status": status, "explanation": explanation}
    store.save_analysis(record)
    return record


def status_message():
    _model, metadata, issue = load_model()
    if issue:
        return issue
    return f"Historical-setting model {metadata.get('model_version', 'version not recorded')} is configured. Outputs are not optimized or production-approved."


@app.exception_handler(RequestValidationError)
async def request_validation_error(request: Request, exc: RequestValidationError):
    logger.info("Invalid request for %s: %s", request.url.path, exc)
    return render(request, "error.html", error="The form was incomplete. Return to the page and provide the requested file or values.", status_code=422)


@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return render(request, "index.html", page_title="CAD Analysis", status_message=status_message())


@app.post("/analyze", response_class=HTMLResponse)
async def analyze(request: Request, file: UploadFile = File(...)):
    try:
        filename, suffix, content = await read_upload(file)
        record = process_content(filename, suffix, content)
    except OverflowError as exc:
        return render(request, "index.html", error=str(exc), status_code=413, status_message=status_message())
    except ValueError as exc:
        code = 415 if "Only .step" in str(exc) else 400 if "selected CAD file is empty" in str(exc) else 422
        return render(request, "index.html", error=str(exc), status_code=code, status_message=status_message())
    except Exception as exc:
        logger.exception("CAD analysis failed")
        return render(request, "index.html", error=f"CAD analysis could not be completed: {exc}", status_code=422, status_message=status_message())
    return render(request, "analysis.html", **analysis_view(record))


@app.get("/analysis/{analysis_id}", response_class=HTMLResponse)
async def reopen_analysis(request: Request, analysis_id: str):
    record = store.get_analysis(analysis_id)
    if not record:
        return render(request, "error.html", error="Analysis not found or already deleted.", status_code=404)
    return render(request, "analysis.html", **analysis_view(record, store.latest_scenario(analysis_id)))


@app.get("/analysis/{analysis_id}/mesh")
async def analysis_mesh(analysis_id: str):
    record = store.get_analysis(analysis_id)
    if not record or not record.get("mesh_path") or not Path(record["mesh_path"]).is_file():
        return Response("Local CAD preview is unavailable.", status_code=404, media_type="text/plain")
    return FileResponse(record["mesh_path"], media_type="model/stl", filename="component-preview.stl")


@app.get("/analysis/{analysis_id}/report.pdf")
async def analysis_report(analysis_id: str):
    record = store.get_analysis(analysis_id)
    if not record:
        return Response("Analysis not found.", status_code=404, media_type="text/plain")
    payload = analysis_pdf(record)
    name = "".join(ch for ch in Path(record["filename"]).stem if ch.isalnum() or ch in "-_ ")[:60] or "analysis"
    return Response(payload, media_type="application/pdf", headers={"Content-Disposition": f'attachment; filename="{name}_hpdc_report.pdf"'})


@app.post("/analysis/{analysis_id}/what-if", response_class=HTMLResponse)
async def what_if(request: Request, analysis_id: str):
    record = store.get_analysis(analysis_id)
    if not record:
        return render(request, "error.html", error="Analysis not found or already deleted.", status_code=404)
    form = await request.form()
    if not record["predictions"]:
        return render(request, "analysis.html", **analysis_view(record), scenario_error="What-if comparison needs baseline parameter estimates, which are unavailable for this analysis.")
    alternatives = {}
    try:
        for key in TARGET_ORDER:
            raw = str(form.get(key, "")).strip()
            if raw:
                value = float(raw)
                if not math.isfinite(value) or value <= 0:
                    raise ValueError(f"Enter a finite positive alternative for {TARGETS[key][0]}.")
                alternatives[key] = value
        if not alternatives:
            raise ValueError("Enter at least one alternative process value.")
    except ValueError as exc:
        return render(request, "analysis.html", **analysis_view(record), scenario_error=str(exc))
    baseline = {row["name"]: row["numeric_value"] for row in record["predictions"]}
    differences = []
    for key, value in alternatives.items():
        old = baseline[key]
        label, unit, _ = TARGETS[key]
        differences.append({"name": key, "label": label, "baseline": old, "alternative": value,
                            "delta": value - old, "unit": unit})
    scenario_id = uuid.uuid4().hex
    store.save_scenario(scenario_id, analysis_id, alternatives, differences)
    scenario = store.latest_scenario(analysis_id)
    return render(request, "analysis.html", **analysis_view(record, scenario))


@app.get("/compare", response_class=HTMLResponse)
async def compare_page(request: Request):
    return render(request, "compare.html")


@app.post("/compare", response_class=HTMLResponse)
async def compare_cad(request: Request, first_file: UploadFile = File(...), second_file: UploadFile = File(...)):
    records = []
    try:
        first = await read_upload(first_file)
        second = await read_upload(second_file)
        records.append(process_content(*first))
        records.append(process_content(*second))
        first_features, second_features = records[0]["features"], records[1]["features"]
        changed = [name for name in FEATURE_NAMES if not math.isclose(first_features[name], second_features[name], rel_tol=1e-5, abs_tol=1e-8)]
        first_pred = {p["name"]: p for p in records[0]["predictions"]}
        second_pred = {p["name"]: p for p in records[1]["predictions"]}
        parameter_changes = []
        for key in TARGET_ORDER:
            if key in first_pred and key in second_pred:
                a, b = first_pred[key], second_pred[key]
                parameter_changes.append({"label": a["label"], "first": a["value"], "second": b["value"], "unit": a["unit"],
                                          "delta": b["numeric_value"] - a["numeric_value"]})
        details = {"first_filename": first[0], "second_filename": second[0], "geometry_changed": bool(changed),
                   "changed_feature_count": len(changed), "parameter_changes": parameter_changes,
                   "prediction_available": bool(parameter_changes),
                   "limitations": "Feature comparison is limited to the supported CAD feature schema; it does not identify every changed face, wall, or design intent. Unit declarations are converted to mm, but confirm part orientation, scale, and export tolerance."}
        comparison_id = uuid.uuid4().hex
        store.save_comparison(comparison_id, records[0]["analysis_id"], records[1]["analysis_id"], details)
        return render(request, "comparison.html", comparison_id=comparison_id, details=details)
    except Exception as exc:
        logger.exception("CAD comparison failed")
        for record in records:
            store.delete_analysis(record["analysis_id"])
        return render(request, "compare.html", error=f"Comparison could not be completed: {exc}", status_code=422)


@app.get("/comparison/{comparison_id}/report.pdf")
async def comparison_report(comparison_id: str):
    comparison = store.get_comparison(comparison_id)
    if not comparison:
        return Response("Comparison not found.", status_code=404)
    d = comparison["details"]
    lines = [f"First component: {d['first_filename']}", f"Second component: {d['second_filename']}",
             f"Relevant extracted geometry changed: {'Yes' if d['geometry_changed'] else 'No detected change in supported features'}",
             d["limitations"], "", "PROCESS ESTIMATE COMPARISON"]
    lines.extend([f"{p['label']}: {p['first']} -> {p['second']} {p['unit']} (delta {p['delta']:.4g})" for p in d["parameter_changes"]] or ["No compatible, verified model was available for estimates."])
    payload = comparison_pdf("HPDC CAD Version Comparison", lines)
    return Response(payload, media_type="application/pdf", headers={"Content-Disposition": f'attachment; filename="cad_comparison_{comparison_id[:8]}.pdf"'})


@app.get("/history", response_class=HTMLResponse)
async def history(request: Request):
    return render(request, "history.html", analyses=store.list_analyses())


@app.post("/history/{analysis_id}/delete")
async def delete_history(analysis_id: str):
    if not store.delete_analysis(analysis_id):
        return Response("Analysis not found.", status_code=404)
    return Response(status_code=303, headers={"Location": "/history"})


@app.get("/batch", response_class=HTMLResponse)
async def batch_page(request: Request):
    return render(request, "batch.html")


@app.post("/batch")
async def batch_analyze(request: Request, files: list[UploadFile] = File(...)):
    if not 1 <= len(files) <= MAX_BATCH_FILES:
        return render(request, "batch.html", error=f"Select between 1 and {MAX_BATCH_FILES} CAD files.", status_code=400)
    records, total = [], 0
    try:
        for upload in files:
            filename, suffix, content = await read_upload(upload)
            total += len(content)
            if total > MAX_BATCH_BYTES:
                raise OverflowError("The combined batch upload must not exceed 100 MB.")
            records.append(process_content(filename, suffix, content))
    except Exception as exc:
        logger.exception("Batch CAD processing failed")
        return render(request, "batch.html", error=str(exc), status_code=413 if isinstance(exc, OverflowError) else 422)
    csv_lines = ["analysis_id,filename,status,model_version," + ",".join(TARGET_ORDER)]
    for record in records:
        prediction = {p["name"]: p["numeric_value"] for p in record["predictions"]}
        fields = [record["analysis_id"], record["filename"], record["status"], (record["metadata"] or {}).get("model_version", "")]
        csv_lines.append(",".join('"' + str(value).replace('"', '""') + '"' for value in fields + [prediction.get(k, "") for k in TARGET_ORDER]))
    csv_content = "\r\n".join(csv_lines) + "\r\n"
    return render(request, "batch.html", records=records, csv_content=csv_content)


@app.get("/model-health", response_class=HTMLResponse)
async def model_health(request: Request):
    model, metadata, issue = load_model()
    datasets = []
    import pandas as pd
    for path in sorted((ROOT / "data").glob("*.csv")):
        try:
            frame = pd.read_csv(path)
            marker = any(frame[col].astype(str).str.contains(r"DEMO|SYNTHETIC|GENERATED", case=False, regex=True).any() for col in ("component_id", "trial_id") if col in frame)
            datasets.append({"name": path.name, "rows": len(frame), "components": int(frame["component_id"].nunique()) if "component_id" in frame else "Not available",
                             "missing_cells": int(frame.isna().sum().sum()), "source": "Synthetic/artifactual markers found" if marker else "Provenance not verified"})
        except Exception as exc:
            datasets.append({"name": path.name, "rows": "Unreadable", "components": "—", "missing_cells": "—", "source": str(exc)})
    return render(request, "model_health.html", model=metadata if model else None, model_issue=issue,
                  datasets=datasets, expected_targets=[{"label": TARGETS[k][0], "key": k} for k in TARGET_ORDER])


@app.get("/quality", response_class=HTMLResponse)
async def quality_status(request: Request):
    return render(request, "quality.html")


@app.get("/health")
async def health():
    model, metadata, issue = load_model()
    return {"status": "ok", "cad_processing_available": True, "model_available": model is not None,
            "model_version": metadata.get("model_version") if metadata else None, "model_issue": issue}


store.initialize()
