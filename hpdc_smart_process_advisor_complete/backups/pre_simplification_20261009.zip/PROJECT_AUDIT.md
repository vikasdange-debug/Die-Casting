# Project audit

**Audit date:** 2026-10-09  
**Root:** `C:\Documents\HPDC\hpdc_smart_process_advisor_complete`

## Architecture and inventory

- Framework: FastAPI (`app.py`, `app:app`), Jinja2 templates in `templates/`, static CSS/JavaScript in `static/`, CadQuery/Open CASCADE STEP import, pandas/scikit-learn/joblib model pipeline, SQLite analysis history.
- Core backend modules reviewed: `app.py`, `analysis_store.py`, `cad_feature_extractor.py`, `engineering_rules.py`, `pdf_reports.py`, `extract_dataset_features.py`, `validate_dataset.py`, and `train_model.py`.
- UI reviewed: all Jinja templates, CSS, upload behavior, and the local CAD preview script. Local STEP/STP fixtures are retained under ignored `uploads/` and used in tests.
- Documentation, dependency configuration, ignore rules, dataset template, validation artifact, saved model and its metadata were inspected. `.venv`, caches, and generated uploads are not application source; they are excluded from tracked source review.
- This workspace does not have a `.git` directory. Prior tracking/history of files cannot be verified.

## Blank `/analyze` issue

The previous handler had a branch for the installed model's `synthetic_demo_only` metadata that did not return a response; it fell through to `None`, producing a blank page after upload. The old test suite asserted successful demo predictions and therefore did not catch the fall-through. The current route always returns a result or actionable HTML error response. Tests exercise a valid CAD upload, malformed CAD, invalid extension, empty upload, and size rejection. CAD processing is preserved when model loading or inference is unavailable.

The current application no longer runs the archived artifact. It reports parameter estimates unavailable because there is no compatible verified real-data model. No parameter values are substituted.

## Model and schema findings

The old saved model metadata identified `model_kind: synthetic_demo_only`, 60 training rows, and 20 components. It supplied the expected feature names and eight targets, but no accepted real-data provenance or valid evaluation metrics. The model was preserved as `models/archived_synthetic_model.joblib`; its metadata was preserved alongside it. It is rejected by the active loader before model deserialization because its model kind is unsupported. It is not a selectable active model.

The existing 13-feature order remains unchanged:

`length_mm`, `width_mm`, `height_mm`, `volume_mm3`, `surface_area_mm2`, `solid_count`, `face_count`, `edge_count`, `vertex_count`, `length_width_ratio`, `length_height_ratio`, `width_height_ratio`, `surface_area_volume_ratio`.

The eight targets remain melt temperature (°C), die temperature (°C), filling time (s), intensification pressure (MPa), fast-shot speed (m/s), vacuum pressure (mbar absolute), cooling time (s), and gate velocity (m/s). Active model loading requires provenance attestation, exact ordered feature and target lists, feature count, per-target nonnegative MAE/RMSE, dataset provenance, and training date. Synthetic/demo/generated/unknown provenance is rejected. Output is historical-setting estimation only; no optimization or quality classification is implemented.

## Dataset provenance and archival action

Both former trial CSVs were inspected. `data/demo_hpdc_trials.csv` and the misleadingly named `data/real_hpdc_trials.csv` contained 60 generated records with `DEMO_PART_*` / `DEMO_TRIAL_*` identifiers. Neither is valid real foundry data. They were renamed, retaining their contents, to `data/archived_synthetic_demo_trials.csv` and `data/archived_mislabeled_synthetic_trials.csv`. Their prior generator, `generate_demo_data.py`, was removed from the active repository workflow. The blank template is retained. The old CSVs are not active training defaults.

There is no verified real HPDC training dataset in the repository, so there is no active process model. No real dataset was downloaded. Previously researched sources did not match the eight parameter targets and geometry schema, or did not provide usable licensed data: a Zenodo record is described as synthetic and does not show a license; a CC BY 4.0 Mendeley dataset covers HPDC alloy chemistry and material properties rather than these process settings; a published industrial quality study did not expose a downloadable dataset or license. Links: [Zenodo record](https://zenodo.org/records/4321371), [Mendeley Data](https://data.mendeley.com/datasets/p3njy3ybgp/1), [study](https://link.springer.com/article/10.1007/s40962-025-01702-8). No data was integrated from these sources.

## CAD, UI, engineering, and report boundaries

- CadQuery imports STEP/STP and Open CASCADE converts declared length units to mm. Unknown/missing unit declarations, empty imports, zero-size geometry, no-solid models, and non-finite features are rejected with visible messages. Multiple solids are retained as an assembly for extraction. The existing known STEP fixture imports as two solids.
- The established 13 features are used internally; the analysis page does not render a geometry metrics table or cards. A local STL preview is generated and served only through the corresponding local analysis route; no third-party viewer receives CAD.
- The engineering checklist deliberately reports “Not assessed”, “Requires die-design information”, or “Simulation required” for properties the CAD part alone cannot establish. No wall thickness, draft, undercut, defect, fill, solidification, manufacturability, or operating limit is asserted.
- The PDF is generated by a small dependency-free text writer. It includes estimates only if available, provenance, findings, warnings, and limitations; it does not expose raw geometry features. No preview image is embedded in this PDF.
- Local SQLite history stores analysis metadata and local random-ID CAD/mesh paths. A History action deletes the record and locally stored files. Upload cap is 25 MB; batches allow up to 10 files and 100 MB total.
- What-if comparison is arithmetic comparison only. The current model schema accepts geometry features, not alternative process setpoints; no alternative inference or optimization is claimed. Quality prediction and external AI assistant are unavailable.

## Known limitations and requirements for real use

The file validator can check schema, value shape, IDs, units encoded in columns, duplicate trial IDs, and synthetic markers; it cannot prove source records, calibration, authorization, or provenance. The training command requires explicit `--confirm-authorized-data`, groups holdout by component ID, records MAE/RMSE and a mean baseline, and saves a model only after evaluation. Adequate external validation, process-context inputs (alloy/machine/die/gating as relevant), target definitions, and engineering review are still required before relying on predictions. This local app has not had a production security assessment.
