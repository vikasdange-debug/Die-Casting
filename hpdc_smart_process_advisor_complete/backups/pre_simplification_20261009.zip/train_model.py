"""Train a grouped historical-setting estimator from authorized HPDC records."""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
from pathlib import Path
import json

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.metrics import mean_absolute_error, mean_squared_error
from sklearn.model_selection import GroupShuffleSplit
from sklearn.multioutput import MultiOutputRegressor
from sklearn.pipeline import Pipeline

ROOT = Path(__file__).resolve().parent
NUMERIC_FEATURES = ["length_mm", "width_mm", "height_mm", "volume_mm3", "surface_area_mm2", "solid_count", "face_count", "edge_count", "vertex_count", "length_width_ratio", "length_height_ratio", "width_height_ratio", "surface_area_volume_ratio"]
FEATURE_COLUMNS = NUMERIC_FEATURES
TARGET_COLUMNS = ["melt_temperature_C", "die_temperature_C", "filling_time_s", "intensification_pressure_MPa", "fast_shot_speed_m_s", "vacuum_pressure_mbar_abs", "cooling_time_s", "gate_velocity_m_s"]
ID_COLUMNS = ["component_id", "trial_id", "source_type", "target_basis", "trial_accepted"]
TARGET_BASES = {"machine_setpoint", "measured_process_value"}
SYNTHETIC_MARKERS = r"(?:^|[^A-Z])DEMO(?:[^A-Z]|$)|SYNTHETIC|GENERATED"
SOURCE_TYPES = {"measured_production", "verified_experimental", "validated_simulation"}
UNITS = {"melt_temperature_C": "°C", "die_temperature_C": "°C", "filling_time_s": "s", "intensification_pressure_MPa": "MPa", "fast_shot_speed_m_s": "m/s", "vacuum_pressure_mbar_abs": "mbar absolute", "cooling_time_s": "s", "gate_velocity_m_s": "m/s"}


def read_table(path):
    path = Path(path)
    if path.suffix.lower() == ".xlsx":
        return pd.read_excel(path)
    if path.suffix.lower() == ".xls":
        raise ValueError("Legacy .xls files are not enabled. Save the workbook as .xlsx or CSV.")
    return pd.read_csv(path)


def join_geometry(trials, geometry):
    """Replace trial-table geometry with CAD export rows joined on component_id."""
    for label, table in (("trial", trials), ("geometry", geometry)):
        if "component_id" not in table:
            raise ValueError(f"{label} table requires a component_id column for a stable join.")
    trials = trials.copy()
    geometry = geometry.copy()
    trials["component_id"] = trials.component_id.astype("string").str.strip()
    geometry["component_id"] = geometry.component_id.astype("string").str.strip()
    if geometry.component_id.isna().any() or (geometry.component_id == "").any() or geometry.component_id.duplicated().any():
        raise ValueError("CAD geometry export must have one nonblank row per component_id.")
    absent = sorted(set(trials.component_id.dropna()) - set(geometry.component_id))
    if absent:
        raise ValueError(f"CAD geometry is missing {len(absent)} trial component IDs (for example {absent[:5]}).")
    joined = trials.drop(columns=[c for c in FEATURE_COLUMNS if c in trials])
    return joined.merge(geometry[["component_id"] + FEATURE_COLUMNS], on="component_id", how="left", validate="many_to_one")


def validate_for_training(df):
    if df.empty:
        raise ValueError("Dataset contains no rows.")
    marker_cols = [c for c in ("component_id", "trial_id", "source_type") if c in df]
    if marker_cols and df[marker_cols].astype(str).apply(lambda s: s.str.contains(SYNTHETIC_MARKERS, case=False, regex=True)).any(axis=None):
        raise ValueError("Synthetic/demo markers found. Synthetic records cannot be trained or labelled as real data.")
    required = ID_COLUMNS + FEATURE_COLUMNS + TARGET_COLUMNS
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError("Missing required columns: " + ", ".join(missing))
    types = set(df.source_type.dropna().astype(str))
    if not types or not types <= SOURCE_TYPES:
        raise ValueError(f"source_type must identify verified provenance using only: {', '.join(sorted(SOURCE_TYPES))}.")
    target_bases = set(df.target_basis.dropna().astype(str))
    if len(target_bases) != 1 or not target_bases <= TARGET_BASES:
        raise ValueError(f"Use one consistent target_basis for the dataset: {', '.join(sorted(TARGET_BASES))}. Do not mix setpoints and measured values.")
    if df.trial_id.isna().any() or df.component_id.isna().any():
        raise ValueError("component_id and trial_id cannot be blank.")
    if df.trial_id.duplicated().any():
        raise ValueError("trial_id must uniquely identify each trial.")
    numeric = FEATURE_COLUMNS + TARGET_COLUMNS + ["trial_accepted"]
    for col in numeric:
        df[col] = pd.to_numeric(df[col], errors="coerce")
        if df[col].isna().any() or not np.isfinite(df[col]).all():
            raise ValueError(f"{col} contains missing, nonnumeric, or non-finite values.")
    positive = ["length_mm", "width_mm", "height_mm", "volume_mm3", "surface_area_mm2",
                "length_width_ratio", "length_height_ratio", "width_height_ratio", "surface_area_volume_ratio"] + TARGET_COLUMNS
    invalid_positive = [col for col in positive if (df[col] <= 0).any()]
    if invalid_positive:
        raise ValueError("These dimensions/ratios/process targets must be positive: " + ", ".join(invalid_positive))
    for col in ["solid_count", "face_count", "edge_count", "vertex_count"]:
        if (df[col] < 0).any() or not np.equal(df[col], np.floor(df[col])).all():
            raise ValueError(f"{col} must contain nonnegative integer topology counts.")
    if not set(df.trial_accepted.unique()) <= {0, 1}:
        raise ValueError("trial_accepted must contain only 0 or 1.")
    df = df[df.trial_accepted == 1].copy()
    if len(df) < 20:
        raise ValueError(f"Only {len(df)} accepted trials remain; at least 20 are required to form an exploratory grouped holdout.")
    if df.component_id.nunique() < 5:
        raise ValueError("At least five distinct component IDs are needed for a grouped holdout; this is only a software guard, not evidence of reliability.")
    return df


def train(data_path, model_path, metadata_path, geometry_path=None):
    raw = read_table(data_path)
    if geometry_path:
        raw = join_geometry(raw, read_table(geometry_path))
    df = validate_for_training(raw)
    types = sorted(df.source_type.astype(str).unique().tolist())
    target_basis = df.target_basis.iloc[0]
    X, y = df[FEATURE_COLUMNS], df[TARGET_COLUMNS]
    groups = df.component_id.astype(str)
    train_idx, test_idx = next(GroupShuffleSplit(n_splits=1, test_size=0.2, random_state=42).split(X, y, groups))
    X_train, X_test = X.iloc[train_idx], X.iloc[test_idx]
    y_train, y_test = y.iloc[train_idx], y.iloc[test_idx]
    estimator = Pipeline([("imputer", SimpleImputer(strategy="median")),
                          ("regressor", MultiOutputRegressor(RandomForestRegressor(n_estimators=300, min_samples_leaf=2, random_state=42, n_jobs=1), n_jobs=1))])
    estimator.fit(X_train, y_train)
    prediction = estimator.predict(X_test)
    baseline = np.tile(y_train.mean(axis=0).to_numpy(), (len(y_test), 1))
    metrics = {}
    for index, target in enumerate(TARGET_COLUMNS):
        metrics[target] = {"mae": float(mean_absolute_error(y_test.iloc[:, index], prediction[:, index])),
                           "rmse": float(np.sqrt(mean_squared_error(y_test.iloc[:, index], prediction[:, index]))),
                           "mean_residual": float(np.mean(prediction[:, index] - y_test.iloc[:, index].to_numpy())),
                           "mean_baseline_mae": float(mean_absolute_error(y_test.iloc[:, index], baseline[:, index])),
                           "unit": UNITS[target]}
    model_path, metadata_path = Path(model_path), Path(metadata_path)
    model_path.parent.mkdir(parents=True, exist_ok=True)
    metadata_path.parent.mkdir(parents=True, exist_ok=True)
    metadata = {"model_version": "1.0", "model_kind": "historical_setting_estimator", "provenance_verified": True, "task": "historical-setting estimation; not optimization or quality prediction",
                "dataset_provenance": "; ".join(sorted(types)), "dataset_path": str(Path(data_path)),
                "geometry_source_path": str(Path(geometry_path)) if geometry_path else "CAD features embedded in trial file",
                "feature_columns": FEATURE_COLUMNS, "feature_units": {k: ("mm" if k.endswith("_mm") else "mm3" if k.endswith("_mm3") else "mm2" if k.endswith("_mm2") else "1/mm" if k == "surface_area_volume_ratio" else "dimensionless") for k in FEATURE_COLUMNS},
                "target_columns": TARGET_COLUMNS, "target_units": UNITS,
                "feature_ranges": {key: {"min": float(X_train[key].min()), "max": float(X_train[key].max())} for key in FEATURE_COLUMNS},
                "target_ranges": {key: {"min": float(y_train[key].min()), "max": float(y_train[key].max())} for key in TARGET_COLUMNS},
                "target_basis": target_basis,
                "training_rows": int(len(df)), "training_components": int(df.iloc[train_idx].component_id.nunique()), "test_rows": int(len(test_idx)),
                "test_components": int(df.iloc[test_idx].component_id.nunique()), "validation_method": "80/20 GroupShuffleSplit by component_id; random_state=42",
                "metrics": metrics, "training_date_utc": datetime.now(timezone.utc).isoformat(),
                "limitations": "Exploratory historical-setting estimates. No evidence of optimality, quality prediction, extrapolation safety, or production readiness. Geometry-only model may omit essential alloy, machine, die, and process context."}
    temporary_model = model_path.with_name(model_path.name + ".tmp")
    temporary_metadata = metadata_path.with_name(metadata_path.name + ".tmp")
    joblib.dump(estimator, temporary_model)
    temporary_metadata.write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    temporary_model.replace(model_path)
    temporary_metadata.replace(metadata_path)
    print(json.dumps({"model": str(model_path), "metadata": str(metadata_path), "metrics": metrics}, indent=2))
    return metadata


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", required=True, help="Authorized CSV or Excel trial file")
    parser.add_argument("--geometry", help="Optional CAD feature CSV/Excel export joined by component_id")
    parser.add_argument("--confirm-authorized-data", action="store_true", help="Attest that this dataset is authorized and its stated provenance is verified")
    parser.add_argument("--model-out", default=str(ROOT / "models" / "hpdc_process_model.joblib"))
    parser.add_argument("--metadata-out", default=str(ROOT / "models" / "hpdc_process_model_metadata.json"))
    args = parser.parse_args()
    if not args.confirm_authorized_data:
        raise SystemExit("Training stopped: pass --confirm-authorized-data only after verifying that the records are authorized and their source type is accurate.")
    try:
        train(args.data, args.model_out, args.metadata_out, args.geometry)
    except Exception as exc:
        raise SystemExit(f"Training stopped; no new model was written: {exc}") from exc


if __name__ == "__main__":
    main()
