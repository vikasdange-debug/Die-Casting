"""Conservative HPDC design-review prompts from part-only input."""

RULES = [
    ("Wall thickness", "Not assessed", "A part-level bounding model does not provide a validated wall-thickness map.", "Run a wall-thickness analysis in CAD and review sections with the die-casting engineer."),
    ("Thin sections and transitions", "Not assessed", "Thin regions and thick-to-thin transitions are not measured by the current extractor.", "Review section thickness and transition radii in CAD; confirm by filling/solidification simulation."),
    ("Draft and release", "Not assessed", "Draft cannot be evaluated without a die pull direction and die surface definition.", "Provide the die-opening direction and check draft on all die-contact faces."),
    ("Undercuts and side cores", "Not assessed", "Undercuts require a defined pull direction and die-action model.", "Review the part against the proposed die opening and side-core actions."),
    ("Parting line and opening", "Not assessed", "No die parting surface or opening direction was supplied.", "Review parting-line location and die-opening feasibility with the die designer."),
    ("Gate and runner", "Requires die-design information", "Gate and runner geometry is not part of the uploaded component model.", "Provide the die/gating design and evaluate gate location and flow balance."),
    ("Overflow and venting", "Requires die-design information", "Overflow and vent features are not represented by the component model.", "Review vent and overflow placement with a validated filling simulation."),
    ("Vacuum system", "Requires process context", "Vacuum hardware, circuit layout, and pressure basis are not supplied by the CAD part.", "Confirm machine vacuum capability and die-circuit requirements."),
    ("Cooling channels", "Requires die-design information", "No die model or cooling-channel layout is available.", "Review cooling layout and thermal balance using die thermal analysis."),
    ("Filling and solidification", "Simulation required", "The application does not perform casting-flow or solidification simulation.", "Validate the proposed process and die design with a suitable, calibrated casting simulation."),
]


def get_engineering_findings(_features):
    """Part-only data cannot support pass/fail conclusions; return transparent review items."""
    return [{"title": title, "status": status, "reason": reason, "next_step": next_step,
             "engineer_review": True} for title, status, reason, next_step in RULES]
