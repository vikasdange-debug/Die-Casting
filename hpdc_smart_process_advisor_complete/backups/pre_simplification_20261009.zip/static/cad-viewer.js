/* Small local STL viewer. CAD files remain on this server; no third-party viewer is used. */
(() => {
  const canvas = document.querySelector('#cad-viewer');
  if (!canvas || !window.CAD_MESH_URL) return;
  const status = document.querySelector('#viewer-status');
  const message = document.querySelector('#viewer-message');
  const gl = canvas.getContext('webgl', { antialias: true, alpha: false });
  if (!gl) { status.textContent = 'Unavailable'; message.textContent = 'This browser does not support the local 3D preview. The CAD analysis is unaffected.'; return; }

  const vertex = `attribute vec3 position; attribute vec3 normal; uniform mat4 mvp; uniform mat4 model; varying vec3 n; void main(){gl_Position=mvp*vec4(position,1.0); n=mat3(model)*normal;}`;
  const fragment = `precision mediump float; varying vec3 n; uniform bool wire; void main(){ if(wire){gl_FragColor=vec4(0.22,0.42,0.44,1.0);return;} vec3 light=normalize(vec3(-0.4,0.8,0.6)); float d=max(dot(normalize(n),light),0.0); gl_FragColor=vec4(vec3(0.25,0.47,0.46)*(0.48+0.52*d),1.0);}`;
  function shader(type, source) { const s=gl.createShader(type); gl.shaderSource(s,source); gl.compileShader(s); if(!gl.getShaderParameter(s,gl.COMPILE_STATUS)) throw Error(gl.getShaderInfoLog(s)); return s; }
  const program=gl.createProgram(); gl.attachShader(program,shader(gl.VERTEX_SHADER,vertex)); gl.attachShader(program,shader(gl.FRAGMENT_SHADER,fragment)); gl.linkProgram(program);
  if(!gl.getProgramParameter(program,gl.LINK_STATUS)){status.textContent='Unavailable';message.textContent='Could not initialize the 3D viewer.';return;}
  gl.useProgram(program);
  const posLoc=gl.getAttribLocation(program,'position'), normLoc=gl.getAttribLocation(program,'normal');
  const mvpLoc=gl.getUniformLocation(program,'mvp'), modelLoc=gl.getUniformLocation(program,'model'), wireLoc=gl.getUniformLocation(program,'wire');
  const posBuffer=gl.createBuffer(), normBuffer=gl.createBuffer(), wireBuffer=gl.createBuffer();
  let positions=[],normals=[],wirePositions=[],center=[0,0,0],scale=1,yaw=.65,pitch=-.45,zoom=1,panX=0,panY=0,wire=false,drag=null;
  const mat4={
    multiply:(a,b)=>{const o=new Float32Array(16);for(let c=0;c<4;c++)for(let r=0;r<4;r++)o[c*4+r]=a[r]*b[c*4]+a[4+r]*b[c*4+1]+a[8+r]*b[c*4+2]+a[12+r]*b[c*4+3];return o;},
    identity:()=>new Float32Array([1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1]),
    perspective:(f,aspect,n,far)=>{const t=1/Math.tan(f/2);return new Float32Array([t/aspect,0,0,0,0,t,0,0,0,0,(far+n)/(n-far),-1,0,0,2*far*n/(n-far),0]);}
  };
  function draw(){
    const ratio=window.devicePixelRatio||1,w=Math.max(1,Math.floor(canvas.clientWidth*ratio)),h=Math.max(1,Math.floor(canvas.clientHeight*ratio));
    if(canvas.width!==w||canvas.height!==h){canvas.width=w;canvas.height=h;gl.viewport(0,0,w,h);}
    gl.clearColor(.933,.949,.945,1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);gl.enable(gl.DEPTH_TEST);
    const model=mat4.identity(),cy=Math.cos(yaw),sy=Math.sin(yaw),cp=Math.cos(pitch),sp=Math.sin(pitch);
    model.set([cy,sy*sp,-sy*cp,0,0,cp,sp,0,sy,-cy*sp,cy*cp,0,0,0,0,1]);
    const projection=mat4.perspective(.72,w/h,.01,100),mvp=mat4.multiply(projection,model);
    mvp[12]=panX;mvp[13]=panY;mvp[14]=-2.7/zoom;
    gl.uniformMatrix4fv(mvpLoc,false,mvp);gl.uniformMatrix4fv(modelLoc,false,model);gl.uniform1i(wireLoc,wire?1:0);
    gl.enableVertexAttribArray(posLoc);gl.enableVertexAttribArray(normLoc);
    if(wire){gl.bindBuffer(gl.ARRAY_BUFFER,wireBuffer);gl.vertexAttribPointer(posLoc,3,gl.FLOAT,false,0,0);gl.disableVertexAttribArray(normLoc);gl.vertexAttrib3f(normLoc,0,0,1);gl.drawArrays(gl.LINES,0,wirePositions.length/3);gl.enableVertexAttribArray(normLoc);}
    else {gl.bindBuffer(gl.ARRAY_BUFFER,posBuffer);gl.vertexAttribPointer(posLoc,3,gl.FLOAT,false,0,0);gl.bindBuffer(gl.ARRAY_BUFFER,normBuffer);gl.vertexAttribPointer(normLoc,3,gl.FLOAT,false,0,0);gl.drawArrays(gl.TRIANGLES,0,positions.length/3);}
  }
  function fit(){yaw=.65;pitch=-.45;zoom=1;panX=0;panY=0;draw();}
  function addTriangle(a,b,c){const ux=b[0]-a[0],uy=b[1]-a[1],uz=b[2]-a[2],vx=c[0]-a[0],vy=c[1]-a[1],vz=c[2]-a[2];let nx=uy*vz-uz*vy,ny=uz*vx-ux*vz,nz=ux*vy-uy*vx,l=Math.hypot(nx,ny,nz)||1;nx/=l;ny/=l;nz/=l;for(const p of [a,b,c]){positions.push(...p);normals.push(nx,ny,nz);}for(const [p,q] of [[a,b],[b,c],[c,a]])wirePositions.push(...p,...q);}
  function parseSTL(buffer){
    const dv=new DataView(buffer),count=buffer.byteLength>=84?dv.getUint32(80,true):0;
    if(count>0&&84+count*50===buffer.byteLength){for(let i=0,o=84;i<count;i++,o+=50){const a=[],b=[],c=[];for(let j=0;j<3;j++)a.push(dv.getFloat32(o+12+j*4,true));for(let j=0;j<3;j++)b.push(dv.getFloat32(o+24+j*4,true));for(let j=0;j<3;j++)c.push(dv.getFloat32(o+36+j*4,true));addTriangle(a,b,c);}}
    else {const text=new TextDecoder().decode(buffer);const values=[];for(const match of text.matchAll(/vertex\s+([-+\d.eE]+)\s+([-+\d.eE]+)\s+([-+\d.eE]+)/g))values.push(match.slice(1).map(Number));if(values.length%3)throw Error('Malformed STL mesh');for(let i=0;i<values.length;i+=3)addTriangle(values[i],values[i+1],values[i+2]);}
    if(!positions.length)throw Error('The preview mesh contains no triangles');
    const mins=[Infinity,Infinity,Infinity],maxs=[-Infinity,-Infinity,-Infinity];for(let i=0;i<positions.length;i+=3)for(let j=0;j<3;j++){mins[j]=Math.min(mins[j],positions[i+j]);maxs[j]=Math.max(maxs[j],positions[i+j]);}
    center=mins.map((v,i)=>(v+maxs[i])/2);const extent=Math.max(...mins.map((v,i)=>maxs[i]-v))||1;scale=2/extent;
    for(let i=0;i<positions.length;i+=3){positions[i]=(positions[i]-center[0])*scale;positions[i+1]=(positions[i+1]-center[1])*scale;positions[i+2]=(positions[i+2]-center[2])*scale;}for(let i=0;i<wirePositions.length;i+=3){wirePositions[i]=(wirePositions[i]-center[0])*scale;wirePositions[i+1]=(wirePositions[i+1]-center[1])*scale;wirePositions[i+2]=(wirePositions[i+2]-center[2])*scale;}
    gl.bindBuffer(gl.ARRAY_BUFFER,posBuffer);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(positions),gl.STATIC_DRAW);gl.bindBuffer(gl.ARRAY_BUFFER,normBuffer);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(normals),gl.STATIC_DRAW);gl.bindBuffer(gl.ARRAY_BUFFER,wireBuffer);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(wirePositions),gl.STATIC_DRAW);
  }
  fetch(window.CAD_MESH_URL,{credentials:'same-origin'}).then(r=>{if(!r.ok)throw Error('Preview mesh is unavailable');return r.arrayBuffer();}).then(parseSTL).then(()=>{status.textContent='Ready';message.hidden=true;fit();}).catch(e=>{status.textContent='Unavailable';message.textContent=e.message+'; engineering processing is unaffected.';});
  canvas.addEventListener('pointerdown',e=>{drag={x:e.clientX,y:e.clientY,pan:e.shiftKey};canvas.setPointerCapture(e.pointerId);});
  canvas.addEventListener('pointermove',e=>{if(!drag)return;const dx=e.clientX-drag.x,dy=e.clientY-drag.y;drag.x=e.clientX;drag.y=e.clientY;if(drag.pan){panX+=dx/canvas.clientWidth*2;panY-=dy/canvas.clientHeight*2;}else{yaw+=dx*.008;pitch=Math.max(-1.52,Math.min(1.52,pitch+dy*.008));}draw();});
  canvas.addEventListener('pointerup',()=>drag=null);canvas.addEventListener('wheel',e=>{e.preventDefault();zoom=Math.max(.25,Math.min(8,zoom*(e.deltaY<0?1.12:.89)));draw();},{passive:false});
  canvas.addEventListener('keydown',e=>{const step=.08;if(e.key==='ArrowLeft')yaw-=step;else if(e.key==='ArrowRight')yaw+=step;else if(e.key==='ArrowUp')pitch=Math.max(-1.52,pitch-step);else if(e.key==='ArrowDown')pitch=Math.min(1.52,pitch+step);else if(e.key==='+'||e.key==='=')zoom=Math.min(8,zoom*1.1);else if(e.key==='-')zoom=Math.max(.25,zoom/1.1);else return;e.preventDefault();draw();});
  document.querySelector('#fit-view')?.addEventListener('click',fit);document.querySelector('#reset-view')?.addEventListener('click',fit);
  document.querySelector('#wireframe')?.addEventListener('click',e=>{wire=!wire;e.currentTarget.setAttribute('aria-pressed',String(wire));e.currentTarget.textContent=wire?'Shaded':'Wireframe';draw();});
  window.addEventListener('resize',draw);
})();
