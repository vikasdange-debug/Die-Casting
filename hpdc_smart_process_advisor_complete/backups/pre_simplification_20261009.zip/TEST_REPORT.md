# Test report

**Run date:** 2026-10-09  
**Environment:** Windows PowerShell, project `.venv`, Python 3.14, installed CadQuery/Open CASCADE and FastAPI test client.

## Baseline before this upgrade

The pre-change test run was not clean: 10 tests passed, one failed because provenance wording did not match, and one errored because the Windows temp path was inaccessible. The earlier unconstrained pytest discovery also attempted to collect restricted `pytest-cache-files-*` directories from the workspace root. The original tests expected the synthetic model/demo UI and did not cover the blank response path.

## Final verification

- `python -m py_compile app.py analysis_store.py cad_feature_extractor.py engineering_rules.py pdf_reports.py train_model.py validate_dataset.py extract_dataset_features.py` — passed.
- `python -m pytest -q` — **14 passed**, no failures (8.57 seconds in the final run).
- Live Uvicorn smoke check (`python -m uvicorn app:app --host 127.0.0.1 --port 8765`): `GET /` returned 200 with the upload form; `GET /health` returned CAD processing available and no active model. Server was stopped after the check.

Tests cover homepage/navigation, known two-solid STEP extraction and schema, valid/invalid/empty/malformed/oversized upload behavior, nonblank unavailable-model result, local STL delivery, PDF download and hidden geometry values, archived synthetic model rejection, schema mismatch detection, all-eight-target prediction adapter formatting, what-if unavailable and comparison behavior, CAD comparison, batch CSV interface, analysis history/reopen/delete, and rejection of synthetic dataset markers.

The prediction adapter contract test uses an in-memory stub solely to verify the eight-target output mapping. It does not train a model or establish predictive quality. No compatible real-data model was available to test genuine fitted-model inference.

## Warnings and limits

- Pytest emits a Starlette deprecation warning that `httpx` is deprecated in its test-client integration in favor of `httpx2`; tests still pass. The requirements retain supported `httpx` for the installed Starlette/TestClient stack.
- CAD extraction and viewer were exercised with the repository's valid STEP fixture. Browser rendering was not visually inspected in an interactive browser; WebGL viewer code is implemented and its mesh endpoint was tested.
- PDF bytes were checked for valid PDF header and report contents. A separate PDF reader/rendering application was not used for visual layout review.
- No production dataset, quality classifier, optimized model, machine operating limits, or casting simulation was available. No production readiness or model accuracy claim is made.
- Four `pytest-cache-files-*` directories created by the initial test-discovery attempt were removed after verifying their exact paths under the project root.
